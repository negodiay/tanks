import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

/**
 * Содержит главный метод для запуска игры.
 */
class GameLauncher {

    public static void main(String[] args) {
        GamePanel game = new GamePanel(); // Создаём экземпляр игрового экрана
        game.init(); // Инициализируем игровой экран
        try {
            // $ java -jar csc413-tankgame-blai30.jar [args]
            game.loadMap(args[0]); // Загружаем карту, переданную в аргументах командной строки
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println(e + ": Аргументы программы не заданы");
            game.loadMap(null); // Если аргументы не переданы, загружаем карту по умолчанию
        }
        GameWindow.gameWindow = new GameWindow(game); // Создаём окно игры и передаём в него игровой экран
        game.launch(); // Запускаем игру
        System.gc(); // Запускаем сборщик мусора
    }

}

/**
 * Окно игры, видимое пользователю, которое содержит всё.
 */
public class GameWindow extends JFrame {

    // РЕКОМЕНДУЕМОЕ МИНИМАЛЬНОЕ РАЗМЕР 1280x960 !
    // Пожалуйста, не используйте меньшие размеры, так как элементы интерфейса игры могут не поместиться должным образом
    static final int SCREEN_WIDTH = Toolkit.getDefaultToolkit().getScreenSize().width; // Ширина экрана
    static final int SCREEN_HEIGHT = Toolkit.getDefaultToolkit().getScreenSize().height;  // Высота экрана
    static final String title = "Tank Game by Stepan | Нажмите F1 для просмотра управления"; // Заголовок окна

    static GameWindow gameWindow; // Статическая переменная для хранения экземпляра окна игры

    /**
     * Конструктор окна игры с необходимыми настройками.
     * @param game Игровая панель, которая будет содержаться внутри окна игры
     */
    GameWindow(JPanel game) {
        this.setTitle(title); // Устанавливаем заголовок окна

        try {
            System.out.println(System.getProperty("user.dir")); // Выводим текущую директорию пользователя
            Image icon = ImageIO.read(this.getClass().getResource("/resources/icon.png")); // Загружаем иконку из ресурсов
            this.setIconImage(icon); // Устанавливаем иконку окна
        } catch (IOException e) {
            System.out.println("IOException: не удаётся прочитать файл изображения");
            e.printStackTrace(); // Выводим стек вызовов в случае ошибки
        }

        this.setLayout(new BorderLayout()); // Устанавливаем менеджер компоновки BorderLayout
        this.setSize(SCREEN_WIDTH, SCREEN_HEIGHT); // Устанавливаем размер окна
        this.setResizable(false); // Запрещаем изменение размера окна
        this.setLocationRelativeTo(null); // Центрируем окно на экране
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Завершаем программу при закрытии окна
//
        this.add(game, BorderLayout.CENTER); // Добавляем игровую панель в центр окна
        this.setVisible(true); // Делаем окно видимым
    }

}