import gameobjects.*;
import util.*;

import javax.swing.*;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * JPanel объект, который содержит всю игру.
 */
public class GamePanel extends JPanel implements Runnable {

    private GameController gameController;
    private Thread thread;

    private boolean running = false;
    private boolean drawDebug = false;  // Рисует различную отладочную информацию для игровых объектов.

    private BufferedReader bufferedReader;
    private BufferedImage background = null;
    private BufferedImage world;
    private Graphics2D buffer;
    private GameHUD gameHUD;

    private String mapFile;
    private HashMap<Integer, BufferedImage> tileMap;    // Tiles for hard walls loaded by bitmask

    private HashMap<Integer, Key> controls1;
    private HashMap<Integer, Key> controls2;

    private Camera camera1;
    private Camera camera2;

    /**
     * Конструктор, используемый для инициализации JPanel игры для JFrame.
     */
    public GamePanel() {
        this.setFocusable(true);
        this.requestFocus();
    }

    /**
     * Инициализатор, который переводит игру в состояние выполнения и активирует метод обновления.
     */
    public void init() {
        this.setControls();
        ResourceCollection.init();
        SpriteCollection.init();
        GameObjectCollection.init();

        this.running = true;
    }

    public void launch() {
        this.gameController = new GameController(this);
        this.addKeyListener(this.gameController);
    }

    /** * Загружает данные из файла для создания карты на основе тайлов. 
     * * "-1" = пустое пространство 
     * * "S" = Мягкая стена 
     * * "H" = Твердая стена 
     * * @param mapFile Имя файла, из которого будет сгенерирована карта */
    
    public void loadMap(String mapFile) {
        this.mapFile = mapFile;
        // Загрузка основных ресурсов: спрайтов, тайлов, фона
        this.background = ResourceCollection.background.getImage();

        // Загрузка файла карты
        try {
            this.bufferedReader = new BufferedReader(new FileReader(mapFile));
        } catch (IOException | NullPointerException e) {
            // Загрузить карту по умолчанию, если файл карты не удалось загрузить.
            System.err.println(e + ": Не удается загрузить файл карты, загружается карта по умолчанию.");
            InputStreamReader defaultMap = new InputStreamReader(this.getClass().getResourceAsStream("/resources/defaultmap.csv"));
            this.bufferedReader = new BufferedReader(defaultMap);
        }

        // Парсинг данных карты из файла
        ArrayList<ArrayList<String>> mapLayout = new ArrayList<>();
        try {
            String currentLine;
            while ((currentLine = bufferedReader.readLine()) != null) {
                if (currentLine.isEmpty()) {
                    continue;
                }
                // Раздели строку на массив строк и добавь к списку массивов.
                mapLayout.add(new ArrayList<>(Arrays.asList(currentLine.split(","))));
            }
        } catch (IOException | NullPointerException e) {
            System.out.println(e + ":Ошибка при разборе данных карты.");
            e.printStackTrace();
        }

        // Размеры карты
        int mapWidth = mapLayout.get(0).size();
        int mapHeight = mapLayout.size();

        this.world = new BufferedImage(mapWidth * 32, mapHeight * 32, BufferedImage.TYPE_INT_RGB);
        this.gameHUD = new GameHUD(this.world);

        // Загрузить тайлы твердых стен
        BufferedImage hardWallTiles = ResourceCollection.tilesHardWall.getImage();
        BufferedImage[][] tiles = new BufferedImage[5][4];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 4; j++) {
                assert hardWallTiles != null;
                tiles[i][j] = hardWallTiles.getSubimage(i * 32, j * 32, 32, 32);
            }
        }
        this.loadTiles(tiles);

        // Сгенерировать всю карту
        for (int y = 0; y < mapHeight; y++) {
            for (int x = 0; x < mapWidth; x++) {
                switch (mapLayout.get(y).get(x)) {
                    case ("-1"):    // Пустой тайл; нет игрового объекта
                        continue;

                    case ("S"):     // Мягкая стена; разрушаемая стена
                        BufferedImage sprSoftWall = SpriteCollection.softWall.getImage();
                        Wall softWall = new Wall(x * 32, y * 32, 0, sprSoftWall, true);
                        GameObjectCollection.spawn(softWall);
                        break;

                    case ("H"):     // Твердая стена; неразрушаемая стена
                        // Код, используемый для выбора тайла на основе соседних тайлов
                        int code = 0;
                        if (y > 0 && mapLayout.get(y - 1).get(x).equals("H")) {
                            code += 1;  // North
                        }
                        if (y < mapHeight - 1 && mapLayout.get(y + 1).get(x).equals("H")) {
                            code += 4;  // South
                        }
                        if (x > 0 && mapLayout.get(y).get(x - 1).equals("H")) {
                            code += 8;  // West
                        }
                        if (x < mapWidth - 1 && mapLayout.get(y).get(x + 1).equals("H")) {
                            code += 2;  // East
                        }

                        Wall hardWall = new Wall(x * 32, y * 32, 0, this.tileMap.get(code), false);
                        GameObjectCollection.spawn(hardWall);
                        break;

                    case ("R"):
                        Spawn respawnPoint = new Spawn(x * 32, y * 32, 0);
                        GameObjectCollection.spawnPoints.add(respawnPoint);
                        break;

                    case ("PH"):    // Пауэр-ап Здоровье
                        Powerup powerHealth = new Powerup(x * 32, y * 32, 0, Powerup.Type.Health);
                        GameObjectCollection.spawn(powerHealth);
                        break;

                    case ("PS"):    // Пауэр-ап Скорость
                        Powerup powerSpeed = new Powerup(x * 32, y * 32, 0, Powerup.Type.Speed);
                        GameObjectCollection.spawn(powerSpeed);
                        break;

                    case ("PF"):    // Пауэр-ап Скорострельность
                        Powerup powerFireRate = new Powerup(x * 32, y * 32, 0, Powerup.Type.FireRate);
                        GameObjectCollection.spawn(powerFireRate);
                        break;

                    case ("PD"):    // Пауэр-ап Урон
                        Powerup powerDamage = new Powerup(x * 32, y * 32, 0, Powerup.Type.Damage);
                        GameObjectCollection.spawn(powerDamage);
                        break;

                    case ("PA"):    // Пауэр-ап Броня
                        Powerup powerArmor = new Powerup(x * 32, y * 32, 0, Powerup.Type.Armor);
                        GameObjectCollection.spawn(powerArmor);
                        break;

                    case ("PM"):    // Powerup Ammo
                        Powerup powerAmmo = new Powerup(x * 32, y * 32, 0, Powerup.Type.Ammo);
                        GameObjectCollection.spawn(powerAmmo);
                        break;

                    case ("WF"):    // Пауэр-ап Огненный шар
                        Powerup powerFireball = new Powerup(x * 32, y * 32, 0, Powerup.Type.Fireball);
                        GameObjectCollection.spawn(powerFireball);
                        break;

                    case ("WB"):    // Пауэр-ап Бумеранг
                        Powerup powerBoomerang = new Powerup(x * 32, y * 32, 0, Powerup.Type.Boomerang);
                        GameObjectCollection.spawn(powerBoomerang);
                        break;

                    case ("PG"):    // Пауэр-ап Золото
                        Powerup powerGold = new Powerup(x * 32, y * 32, 0, Powerup.Type.Gold);
                        GameObjectCollection.spawn(powerGold);
                        break;

                    case ("1"):     // Танк игрока 1
                        BufferedImage sprTank1 = SpriteCollection.tank1.getImage();
                        BufferedImage sprBullet1 = SpriteCollection.bullet1.getImage();
                        Tank tank1 = new Tank(x * 32, y * 32, 90f, sprTank1, sprBullet1);
                        this.camera1 = new Camera(tank1);
                        PlayerController tankController1 = new PlayerController(tank1, this.controls1);
                        this.addKeyListener(tankController1);
                        this.gameHUD.assignPlayer(0, tank1);
                        GameObjectCollection.spawn(tank1);
                        break;

                    case ("2"):     // Танк игрока 2
                        BufferedImage sprTank2 = SpriteCollection.tank2.getImage();
                        BufferedImage sprBullet2 = SpriteCollection.bullet2.getImage();
                        Tank tank2 = new Tank(x * 32, y * 32, 270f, sprTank2, sprBullet2);
                        this.camera2 = new Camera(tank2);
                        PlayerController tankController2 = new PlayerController(tank2, this.controls2);
                        this.addKeyListener(tankController2);
                        this.gameHUD.assignPlayer(1, tank2);
                        GameObjectCollection.spawn(tank2);
                        break;

                    default:
                        break;
                }
            }
        }
    }

    /**
 * Вызывается в loadMap для загрузки тайловой карты для спрайтов твёрдой стены.
 * Правильный спрайт выбирается для твёрдой стены на основе соседних твёрдых стен.
 * @param tiles Двумерный массив нарезанной тайловой карты
 */
    private void loadTiles(BufferedImage[][] tiles) {
        this.tileMap = new HashMap<>();
        /*
            [ ][1][ ]
            [8][X][2]
            [ ][4][ ]
            1st bit = north
            2nd bit = east
            3rd bit = south
            4th bit = west
            Эти биты указывают на наличие соседней твёрдой стены в том направлении
         */
        this.tileMap.put(0b0000, tiles[0][0]);  // 0

        this.tileMap.put(0b0001, tiles[2][0]);  // N
        this.tileMap.put(0b0010, tiles[3][0]);  // E
        this.tileMap.put(0b0100, tiles[1][0]);  // S
        this.tileMap.put(0b1000, tiles[4][0]);  // W

        this.tileMap.put(0b0011, tiles[3][2]);  // N E
        this.tileMap.put(0b1001, tiles[4][2]);  // N W
        this.tileMap.put(0b0110, tiles[1][2]);  // S E
        this.tileMap.put(0b1100, tiles[2][2]);  // S W

        this.tileMap.put(0b1010, tiles[0][3]);  // W E
        this.tileMap.put(0b0101, tiles[0][2]);  // N S

        this.tileMap.put(0b1011, tiles[2][1]);  // N E W
        this.tileMap.put(0b0111, tiles[3][1]);  // N E S
        this.tileMap.put(0b1110, tiles[1][1]);  // S E W
        this.tileMap.put(0b1101, tiles[4][1]);  // S W N

        this.tileMap.put(0b1111, tiles[0][1]);  // N S W E
    }

    /**
     * Инициализация привязки клавиш для игрока 1 и игрока 2.
     */
    private void setControls() {
        this.controls1 = new HashMap<>();
        this.controls2 = new HashMap<>();

        // Установить управление Игрока 1
		this.controls1.put(KeyEvent.VK_UP, Key.up);
		this.controls1.put(KeyEvent.VK_DOWN, Key.down);
		this.controls1.put(KeyEvent.VK_LEFT, Key.left);
		this.controls1.put(KeyEvent.VK_RIGHT, Key.right);
		this.controls1.put(KeyEvent.VK_SLASH, Key.action);
		
		// Установить управление Игрока 2
		this.controls2.put(KeyEvent.VK_W, Key.up);
		this.controls2.put(KeyEvent.VK_S, Key.down);
		this.controls2.put(KeyEvent.VK_A, Key.left);
		this.controls2.put(KeyEvent.VK_D, Key.right);
		this.controls2.put(KeyEvent.VK_F, Key.action);
    }

	public void addNotify() {
	    super.addNotify();
	
	    if (this.thread == null) {
	        this.thread = new Thread(this, "GameThread");
	        this.thread.start();
	    }
	}
	
	/**
	 * При нажатии ESC закрыть игру
	 */
	public void exit() {
	    System.exit(0);
	}
	
	/**
	 * При нажатии F5 сбросить коллекцию игровых объектов, собрать мусор, 
	 * переинициализировать игровую панель и перезагрузить карту
	 */
	public void resetGame() {
	    GameObjectCollection.init();
	    System.gc();
	    this.init();
	    this.loadMap(this.mapFile);
	}

	/**
	 * Игра начинает работать и продолжает работать.
	 */
	@Override
	public void run() {
	    long timer = System.currentTimeMillis();
	    long lastTime = System.nanoTime();
	
	    final double NS = 1000000000.0 / 60.0; // Зафиксированные тики в секунду — 60
	    double delta = 0;
	    int fps = 0;    // Кадры в секунду
	    int ticks = 0;  // Тики/Обновления в секунду; должно быть 60 всё время
	
	    // Подсчёт FPS, тиков и выполнение обновлений
	    while (this.running) {
	        long currentTime = System.nanoTime();
	
	        delta += (currentTime - lastTime) / NS;
	        lastTime = currentTime;
	        if (delta >= 1) {
	            this.update();
	            ticks++;
	            delta--;
	        }
	        this.repaint();
	        fps++;
	
	        // Обновление счётчика FPS и тиков каждую секунду
	        if (System.currentTimeMillis() - timer > 1000) {
	            timer = System.currentTimeMillis();
	            System.out.println("FPS: " + fps + ", Ticks: " + ticks);
	            GameWindow.gameWindow.setTitle(GameWindow.title + " | " + "FPS: " + fps + ", Ticks: " + ticks);
	            fps = 0;
	            ticks = 0;
	        }
	    }
	}

    /**
 * Обновляет состояние игры, вызывая метод обновления для всех игровых объектов
 * в коллекции, камер, HUD игры и перерисовывает экран.
 */
	private void update() {
	    try {
	        for (int i = 0; i < GameObjectCollection.numGameObjects(); ) {
	            GameObject obj = GameObjectCollection.getGameObject(i);
	            obj.update();
	            if (obj.isDestroyed()) {
	                // Уничтожить и удалить игровые объекты, помеченные для удаления
	                GameObjectCollection.destroy(obj);
	            } else {
	                for (int j = 0; j < GameObjectCollection.numGameObjects(); j++) {
	                    GameObject collidingObj = GameObjectCollection.getGameObject(j);
	                    // Пропустить обнаружение столкновения с тем же объектом
	                    if (obj == collidingObj) {
	                        continue;
	                    }
	
	                    // Обработка столкновений с использованием паттерна Посетитель
	                    if (obj.getCollider().intersects(collidingObj.getCollider())) {
	                        obj.collides(collidingObj);
	                    }
	                }
                	i++;
            	}
        	}
        	Thread.sleep(1000 / 144); // Ограничить FPS до 144
    	} catch (InterruptedException ignored) {

	    }
	}

	/**
	 * Постоянно перерисовывает экран в соответствии с состоянием игры.
	 * @param g То, что отображается на экране
	 */
	@Override
	public void paintComponent(Graphics g) {
	    Graphics2D g2 = (Graphics2D) g;
	    this.buffer = this.world.createGraphics();
	    this.buffer.clearRect(0, 0, this.world.getWidth(), this.world.getHeight());
	    super.paintComponent(g2);
	
	    // Установить фон окна в чёрный цвет
	    g2.setColor(Color.BLACK);
	    g2.fillRect(0, 0, getWidth(), getHeight());
	
	    // Рисуем фон
	    for (int i = 0; i < this.world.getWidth(); i += this.background.getWidth()) {
	        for (int j = 0; j < this.world.getHeight(); j += this.background.getHeight()) {
	            this.buffer.drawImage(this.background, i, j, null);
	        }
	    }

    	// Рисуем игровые объекты
	    for (int i = 0; i < GameObjectCollection.numGameObjects(); i++) {
	        GameObject obj = GameObjectCollection.getGameObject(i);
	        obj.drawGizmos(this.buffer);    // Рисуем вспомогательные элементы под собственным спрайтом
	        obj.drawImage(this.buffer);
	
	        // Рисуем отладочную информацию
	        if (this.drawDebug) {
	            this.buffer.setColor(Color.WHITE);
	            obj.drawCollider(this.buffer);
	            obj.drawTransform(this.buffer);
	            obj.drawVariables(this.buffer);
	        }
	    }
	
	    // Обновляем камеры и HUD игры, затем перерисовываем их на экране
	    this.camera1.redraw(this.world);
	    this.camera2.redraw(this.world);
	    this.gameHUD.redraw(this.world);
	    g2.drawImage(this.camera1.getScreen(), 0, 0, null);
	    g2.drawImage(this.camera2.getScreen(), GameWindow.SCREEN_WIDTH / 2, 0, null);
	    g2.drawImage(this.gameHUD.getP1info(), 0, GameWindow.SCREEN_HEIGHT - (GameWindow.SCREEN_HEIGHT * 4 / 11), null);
	    g2.drawImage(this.gameHUD.getP2info(), (GameWindow.SCREEN_WIDTH / 2) + (this.gameHUD.getMinimapWidth() / 2), GameWindow.SCREEN_HEIGHT - (GameWindow.SCREEN_HEIGHT * 4 / 11), null);
	    g2.drawImage(this.gameHUD.getMinimap(), (GameWindow.SCREEN_WIDTH / 2) - (this.gameHUD.getMinimapWidth() / 2), GameWindow.SCREEN_HEIGHT - (GameWindow.SCREEN_HEIGHT * 4 / 11), null);
	
	    g2.dispose();
	    this.buffer.dispose();
	}
}

/**
 * Используется для управления игрой
 */
class GameController implements KeyListener {

    private GamePanel gamePanel;

    public GameController(GamePanel gamePanel) {
        this.gamePanel = gamePanel;
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    /**
	 * События клавиш для общих операций в игре, таких как выход
	 * @param e Нажатая клавиша на клавиатуре
	 */
	@Override
	public void keyPressed(KeyEvent e) {
	    // Закрыть игру
	    if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
	        System.out.println("Нажата клавиша Escape: Закрытие игры");
	        this.gamePanel.exit();
	    }

    	// Показать управление
	    if (e.getKeyCode() == KeyEvent.VK_F1) {
	        System.out.println("Нажата клавиша F1: Показ помощи");
	
	        String[] columnHeaders = { "", "Игрок 1", "Игрок 2" };
	        Object[][] controls = {
	                {"Вперёд", "Вверх", "W"},
	                {"Назад", "Вниз", "S"},
	                {"Повернуть налево", "Влево", "A"},
	                {"Повернуть направо", "Вправо", "D"},
	                {"Стрельба", "/", "F"},
	                {"", "", ""},
	                {"Помощь", "F1", ""},
	                {"Сброс", "F5", ""},
	                {"Выход", "ESC", ""} };
	
	        JTable controlsTable = new JTable(controls, columnHeaders);
	        JTableHeader tableHeader = controlsTable.getTableHeader();
	
	        // Обернуть JTable в JPanel для отображения
	        JPanel panel = new JPanel();
	        panel.setLayout(new BorderLayout());
	        panel.add(tableHeader, BorderLayout.NORTH);
	        panel.add(controlsTable, BorderLayout.CENTER);
	
	        JOptionPane.showMessageDialog(this.gamePanel, panel, "Управление", JOptionPane.PLAIN_MESSAGE);
	    }

    	// Сбросить игру
	    if (e.getKeyCode() == KeyEvent.VK_F5) {
	        System.out.println("Нажата клавиша F5: Сброс игры");
	        this.gamePanel.resetGame();
	    }
	}

	@Override
	public void keyReleased(KeyEvent e) {
	
	}
}
