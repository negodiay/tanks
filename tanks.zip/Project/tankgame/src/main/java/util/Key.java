package util;

/**
 * Привязки клавиш, используемые для управления игроком.
 * Создайте объект HashMap, который связывает эти клавиши с клавишами на клавиатуре для управления игроком.
 */
public class Key {

    public static Key up = new Key();
    public static Key down = new Key();
    public static Key left = new Key();
    public static Key right = new Key();
    public static Key action = new Key();

}
