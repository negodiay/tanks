package util;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Коллекция ресурсов для игры, загружаемых из
 */
public enum ResourceCollection {

    background,
    tilesHardWall;

    private BufferedImage image = null;

    public BufferedImage getImage() {
        return this.image;
    }

    // Загружает ресурсы с диска
    public static void init() {
        try {
            background.image = ImageIO.read(ResourceCollection.class.getResource("/resources/bg.jpg"));
            tilesHardWall.image = ImageIO.read(ResourceCollection.class.getResource("/resources/wall_tiles.png"));
        } catch (IOException e) {
            System.err.println(e + ": Невозможно прочитать файл изображения");
            e.printStackTrace();
        }
    }

}
