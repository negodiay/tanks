import java.awt.image.BufferedImage;

import gameobjects.GameObject;

/**
 * Объекты камеры предоставляют экран для каждого игрока, который следует за назначенным танком.
 */
public class Camera {

    private static final int WIDTH = (GameWindow.SCREEN_WIDTH / 2) - 2;
    private static final int HEIGHT = (GameWindow.SCREEN_HEIGHT * 7 / 11);

    private GameObject trackObject;
    private BufferedImage view;

    /**
     * Назначает игровой объект этой камере, за которым она будет следовать.
     * @param obj Игровой объект, за которым будет следовать камера
     */
    public Camera(GameObject obj) {
        this.trackObject = obj;
    }

    /**
     * Непрерывно обрезает игровую сцену до размеров камеры.
     * @param world Игровой мир, переданный в main.java.GamePanel, который будет обрезан этой камерой
     */
    public void redraw(BufferedImage world) {
        float x = this.trackObject.getTransform().getPositionX() + this.trackObject.getOriginOffset().getX() - ((float) WIDTH / 2);
        float y = this.trackObject.getTransform().getPositionY() + this.trackObject.getOriginOffset().getY() - ((float) HEIGHT / 2);

        // Остановка прокрутки при достижении левого или правого края карты
        if (x <= 0) {
            x = 0;
        } else if (x >= world.getWidth() - WIDTH) {
            x = world.getWidth() - WIDTH;
        }

        // Остановка прокрутки при достижении верхнего или нижнего края карты
        if (y <= 0) {
            y = 0;
        } else if (y >= world.getHeight() - HEIGHT) {
            y = world.getHeight() - HEIGHT;
        }

        this.view = world.getSubimage((int) x, (int) y, WIDTH, HEIGHT);
    }

    /**
     * Вызывается main.java.GamePanel для отрисовки камеры на экране.
     * @return Этот вид данного объекта камеры
     */
    public BufferedImage getScreen() {
        return this.view;
    }

}
