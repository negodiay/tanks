import gameobjects.Player;
import util.Key;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashMap;

/**
 * Этот класс управляет объектом игрока через пользовательский ввод, 
 * слушая события нажатия клавиш.
 */
public class PlayerController implements KeyListener {

    private Player player; // Объект игрока
    private HashMap<Integer, Key> controls; // Управление для игрока

    /**
     * Назначает управление объекту игры игрока.
     * @param obj Объект игры игрока, который будет управляться
     * @param controls Управление, которое будет контролировать объект игры игрока
     */
    public PlayerController(Player obj, HashMap<Integer, Key> controls) {
        this.player = obj; // Инициализация объекта игрока
        this.controls = controls; // Инициализация управления
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Метод не используется
    }

    /**
     * Читает нажатые клавиши и выполняет определённые действия в зависимости от нажатой клавиши.
     * @param e Нажатая клавиша
     */
    @Override
    public void keyPressed(KeyEvent e) {
        if (this.controls.get(e.getKeyCode()) == Key.up) {
            this.player.toggleUpPressed(); // Переключаем состояние "вверх"
        }
        if (this.controls.get(e.getKeyCode()) == Key.down) {
            this.player.toggleDownPressed(); // Переключаем состояние "вниз"
        }

        if (this.controls.get(e.getKeyCode()) == Key.left) {
            this.player.toggleLeftPressed(); // Переключаем состояние "влево"
        }
        if (this.controls.get(e.getKeyCode()) == Key.right) {
            this.player.toggleRightPressed(); // Переключаем состояние "вправо"
        }

        if (this.controls.get(e.getKeyCode()) == Key.action) {
            this.player.toggleActionPressed(); // Переключаем состояние "действие"
        }
    }

    /**
     * Читает отпущенные клавиши и выполняет определённые действия в зависимости от отпущенной клавиши.
     * @param e Отпущенная клавиша
     */
    @Override
    public void keyReleased(KeyEvent e) {
        if (this.controls.get(e.getKeyCode()) == Key.up) {
            this.player.unToggleUpPressed(); // Сбрасываем состояние "вверх"
        }
        if (this.controls.get(e.getKeyCode()) == Key.down) {
            this.player.unToggleDownPressed(); // Сбрасываем состояние "вниз"
        }

        if (this.controls.get(e.getKeyCode()) == Key.left) {
            this.player.unToggleLeftPressed(); // Сбрасываем состояние "влево"
        }
        if (this.controls.get(e.getKeyCode()) == Key.right) {
            this.player.unToggleRightPressed(); // Сбрасываем состояние "вправо"
        }

        if (this.controls.get(e.getKeyCode()) == Key.action) {
            this.player.unToggleActionPressed(); // Сбрасываем состояние "действие"
        }
    }
}