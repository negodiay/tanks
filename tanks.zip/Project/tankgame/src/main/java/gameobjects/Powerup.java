package gameobjects;

import util.SpriteCollection;
import util.Transform;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * Усиления (Powerups) с предопределёнными типами, которые появляются случайным образом из разрушаемых стен.
 * Эти усиления предоставляют танкам различные бонусы при столкновении.
 */
public class Powerup extends GameObject {

    public enum Type {
        // Увеличение здоровья
        Health(SpriteCollection.powerHealth.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addHealth(2);
            }
        },

        // Увеличение скорости
        Speed(SpriteCollection.powerSpeed.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addSpeed(1);
            }
        },

        // Увеличение скорострельности
        FireRate(SpriteCollection.powerFireRate.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addFireRate(1);
            }
        },

        // Увеличение урона
        Damage(SpriteCollection.powerDamage.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addDamage(1);
            }
        },

        // Увеличение брони
        Armor(SpriteCollection.powerArmor.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addArmor(1);
            }
        },

        // Увеличение боеприпасов
        Ammo(SpriteCollection.powerAmmo.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addAmmo(20);
            }
        },

        // Получение оружия "Огненный шар"
        Fireball(SpriteCollection.powerFireball.getImage(), SpriteCollection.fireball.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.setWeapon(Weapon.Type.Fireball, this.sprPower);
            }
        },

        // Получение оружия "Бумеранг"
        Boomerang(SpriteCollection.powerBoomerang.getImage(), SpriteCollection.boomerang.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.setWeapon(Weapon.Type.Boomerang, this.sprPower);
            }
        },

        // Увеличение всех характеристик до максимума
        // Этот тип должен быть последним, чтобы исключить его из пула случайных усилений
        Gold(SpriteCollection.powerGold.getImage(), SpriteCollection.tankGold.getImage()) {
            @Override
            protected void grantBonus(Tank tank) {
                tank.addHealth(20);
                tank.addSpeed(10);
                tank.addFireRate(10);
                tank.addDamage(10);
                tank.addArmor(10);
                tank.addAmmo(999);
                tank.setSprite(this.sprPower);
            }
        };

        protected BufferedImage sprite; // Изображение усиления
        protected BufferedImage sprPower = null; // Изображение, связанное с усилением (например, новое оружие)

        // Для усилений, увеличивающих характеристики
        Type(BufferedImage sprite) {
            this.sprite = sprite;
        }

        // Для оружия и усилений максимальных характеристик
        Type(BufferedImage sprite, BufferedImage sprPower) {
            this.sprite = sprite;
            this.sprPower = sprPower;
        }

        protected abstract void grantBonus(Tank tank); // Метод для предоставления бонуса танку
    }

    private Type type; // Тип усиления

    // Конструктор случайного усиления (кроме Gold)
    public Powerup() {
        this.transform = new Transform();
        this.type = this.randomPower();
        this.construct(this.type.sprite);
    }

    // Конструктор определённого усиления
    public Powerup(Powerup.Type type) {
        this.transform = new Transform();
        this.type = type;
        this.construct(this.type.sprite);
    }

    // Конструктор определённого усиления с указанием местоположения
    public Powerup(float xPosition, float yPosition, float rotation, Powerup.Type type) {
        this.type = type;
        this.construct(xPosition, yPosition, rotation, this.type.sprite);
    }

    // Случайные усиления
    private Powerup.Type[] powerups = Powerup.Type.values(); // Массив всех типов усилений
    private Random random = new Random(); // Объект для генерации случайных чисел

    private final Powerup.Type randomPower() {
        // Исключить Gold из случайного выбора
        return this.powerups[this.random.nextInt(this.powerups.length - 1)];
    }

    void grantBonus(Tank tank) {
        this.type.grantBonus(tank); // Предоставить бонус танку
    }

    @Override
    public void update() {
        // Игнорируется, так как усиления не выполняют действия
    }

    @Override
    public void collides(GameObject collidingObj) {
        collidingObj.handleCollision(this); // Обработка столкновения с усилением
    }

    @Override
    public void handleCollision(Tank collidingTank) {
        // Реакция на столкновение с танком
    }

    @Override
    public void handleCollision(Wall collidingWall) {
        // Реакция на столкновение со стеной
    }

    @Override
    public void handleCollision(Weapon collidingWeapon) {
        // Реакция на столкновение с оружием
    }

    @Override
    public void handleCollision(Powerup collidingPowerup) {
        // Реакция на столкновение с другим усилением
    }

    @Override
    public void drawGizmos(Graphics g) {
        // Отрисовка дополнительных данных об объекте (не используется для усилений)
    }

    @Override
    public void drawVariables(Graphics g) {
        // Отрисовка переменных объекта (не используется для усилений)
    }

}