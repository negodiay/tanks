package gameobjects;

import java.util.HashMap;
import java.util.LinkedHashMap;

/**
 * Игровой объект, расширяющий этот класс, может управляться игроком.
 */
public abstract class Player extends GameObject {

    protected boolean UpPressed = false; // Флаг нажатия кнопки "вверх"
    protected boolean DownPressed = false; // Флаг нажатия кнопки "вниз"
    protected boolean LeftPressed = false; // Флаг нажатия кнопки "влево"
    protected boolean RightPressed = false; // Флаг нажатия кнопки "вправо"
    protected boolean ActionPressed = false; // Флаг нажатия кнопки действия

    protected LinkedHashMap<String, Integer> statsCollection; // Коллекция характеристик игрока

    protected final int MAX_HP = 20; // Максимальное количество здоровья
    protected final int MAX_LIVES = 5; // Максимальное количество жизней

    protected int currentHP; // Текущее количество здоровья
    protected int currentLives; // Текущее количество жизней

    protected boolean loser; // Флаг, указывающий, проиграл ли игрок

    public void toggleUpPressed() {
        this.UpPressed = true; // Устанавливает флаг нажатия кнопки "вверх"
    }

    public void toggleDownPressed() {
        this.DownPressed = true; // Устанавливает флаг нажатия кнопки "вниз"
    }

    public void toggleLeftPressed() {
        this.LeftPressed = true; // Устанавливает флаг нажатия кнопки "влево"
    }

    public void toggleRightPressed() {
        this.RightPressed = true; // Устанавливает флаг нажатия кнопки "вправо"
    }

    public void toggleActionPressed() {
        this.ActionPressed = true; // Устанавливает флаг нажатия кнопки действия
    }

    public void unToggleUpPressed() {
        this.UpPressed = false; // Сбрасывает флаг нажатия кнопки "вверх"
    }

    public void unToggleDownPressed() {
        this.DownPressed = false; // Сбрасывает флаг нажатия кнопки "вниз"
    }

    public void unToggleLeftPressed() {
        this.LeftPressed = false; // Сбрасывает флаг нажатия кнопки "влево"
    }

    public void unToggleRightPressed() {
        this.RightPressed = false; // Сбрасывает флаг нажатия кнопки "вправо"
    }

    public void unToggleActionPressed() {
        this.ActionPressed = false; // Сбрасывает флаг нажатия кнопки действия
    }

    public float getHPRatio() {
        return Math.min(1, (float) this.currentHP / (float) this.MAX_HP); // Возвращает отношение текущего здоровья к максимальному
    }

    public int getCurrentLives() {
        return this.currentLives; // Возвращает текущее количество жизней
    }

    public int getMaxLives() {
        return this.MAX_LIVES; // Возвращает максимальное количество жизней
    }

    public boolean isLoser() {
        return this.loser; // Проверяет, проиграл ли игрок
    }

    public abstract String getNameWeapon(); // Получает имя оружия

    public abstract float getCooldownRatio(); // Возвращает отношение текущего времени перезарядки к максимальному

    public abstract HashMap<String, Integer> getStats(); // Возвращает коллекцию характеристик игрока

}
