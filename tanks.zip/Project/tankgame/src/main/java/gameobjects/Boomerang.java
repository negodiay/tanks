package gameobjects;

import util.Transform;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Boomerang extends Weapon {

    private float spin; // Отдельная переменная для вращения, используемая для анимации вращающегося спрайта

    /**
     * Создает новый объект бумеранга с базовыми данными.
     * @param sprite Изображение этого снаряда, переданное объектом танка для отрисовки на экране
     * @param damage Дополнительный урон, переданный от объекта танка, добавляется к базовому урону
     * @param shooter Танк, который выпустил этот снаряд, предотвращает попадание в самого себя
     */
    public Boomerang(BufferedImage sprite, int damage, Tank shooter) {
        this.transform = new Transform();
        this.construct(sprite);
        this.shooter = shooter;

        Random rand = new Random();
        this.spin = rand.nextInt(360); // Устанавливаем случайное начальное вращение

        this.damage += damage; // Увеличиваем базовый урон, добавляя переданный параметр damage
        this.init();
    }

    /**
     * Инициализирует оружие с параметрами по умолчанию.
     */
    @Override
    protected void init() {
        this.velocity = 12.0f; // Начальная скорость
        this.hitPoints = 1;   // Количество здоровья бумеранга (например, он исчезает после одного попадания)
    }

    /**
     * Постоянно движется в направлении, заданном текущим поворотом объекта бумеранга, с учетом скорости.
     * Бумеранг замедляется, пока в конечном итоге не начнет двигаться в обратном направлении.
     * Увеличивает переменную spin, которая используется для анимации вращения бумеранга.
     */
    @Override
    public void update() {
        this.collider.setRect(this.transform.getPositionX(), this.transform.getPositionY(), this.width, this.height);
        // Уменьшаем скорость, чтобы бумеранг в конечном итоге полетел обратно
        this.transform.move(this.velocity);
        this.velocity = Math.max(-16.0f, this.velocity - 0.2f); // Ограничиваем минимальную скорость
        this.spin += 20; // Увеличиваем значение spin для анимации вращения
    }

    /**
     * Использует отдельное значение для вращения (spin), которое не зависит от движения, для отрисовки вращающегося бумеранга.
     */
    @Override
    public void drawImage(Graphics g) {
        AffineTransform rotation = AffineTransform.getTranslateInstance(this.transform.getPositionX(), this.transform.getPositionY());
        rotation.rotate(Math.toRadians(this.spin), this.sprite.getWidth() / 2.0, this.sprite.getHeight() / 2.0);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(this.sprite, rotation, null); // Отрисовка изображения с учетом вращения
    }

}
