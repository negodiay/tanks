package gameobjects;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.LinkedHashMap;
import java.util.Random;

/**
 * Объект "Танк", которым управляет игрок.
 */
public class Tank extends Player {

    /*  Унаследованные поля из абстрактного класса Player:
        boolean UpPressed
        boolean DownPressed
        boolean LeftPressed
        boolean RightPressed
        boolean ActionPressed
        int MAX_HP
        int MAX_LIVES
        int currentHP
        int currentLives
    */

    private final float ROTATION_SPEED = 2.5f; // Скорость вращения танка

    private BufferedImage originalSprite;   // Сохраняет оригинальный спрайт танка (для восстановления после использования powerGold)
    private BufferedImage bulletSprite;     // Сохраняет спрайт пули, используется при возрождении с другим оружием
    private BufferedImage weaponSprite;     // Спрайт текущего оружия
    private Weapon projectile;              // Объект текущего оружия
    private Weapon.Type currentWeapon;      // Тип текущего оружия

    private int moveSpeed;   // Скорость передвижения
    private int fireRate;    // Скорострельность
    private int damage;      // Урон
    private int armor;       // Броня
    private int ammo;        // Количество боеприпасов

    private float fireCooldown; // Задержка между выстрелами
    private float fireDelay;    // Общая продолжительность задержки между выстрелами

    /**
     * Создает объект танка с заданными координатами, поворотом и спрайтами.
     * @param xPosition Координата X танка в игровом мире
     * @param yPosition Координата Y танка в игровом мире
     * @param rotation Угол поворота танка в градусах
     * @param sprite Спрайт танка
     * @param weaponSprite Спрайт текущего оружия, которое будет стрелять танк
     */
    public Tank(float xPosition, float yPosition, float rotation, BufferedImage sprite, BufferedImage weaponSprite) {
        this.construct(xPosition, yPosition, rotation, sprite); // Инициализация основных параметров
        this.originalSprite = this.sprite;
        this.weaponSprite = weaponSprite;
        this.bulletSprite = weaponSprite;

        this.init(); // Инициализация стандартных параметров
    }

    /**
     * Инициализирует стандартное оружие и характеристики.
     */
    private void init() {
        this.currentWeapon = Weapon.Type.Bullet; // Оружие по умолчанию — пули
        this.currentHP = this.MAX_HP;
        this.currentLives = this.MAX_LIVES;

        this.statsCollection = new LinkedHashMap<>();
        this.moveSpeed = 4;
        this.fireRate = 1;
        this.damage = 1;
        this.armor = 0;
        this.ammo = 50;

        this.fireDelay = 60f; // Интервал между выстрелами
        this.fireCooldown = this.fireDelay; // Задержка перезарядки
        this.loser = false; // Указатель, проиграл ли танк
    }

    /**
     * Сбрасывает HP, оружие, боеприпасы и снижает характеристики на 2 при возрождении.
     */
    private void respawn() {
        this.currentHP = this.MAX_HP;
        this.currentWeapon = Weapon.Type.Bullet;
        this.sprite = this.originalSprite;
        this.weaponSprite = this.bulletSprite;

        // Уменьшение характеристик
        this.moveSpeed = Math.max(4, this.moveSpeed - 2);
        this.fireRate = Math.max(1, this.fireRate - 2);
        this.damage = Math.max(1, this.damage - 2);
        this.armor = Math.max(0, this.armor - 2);
        this.ammo = 50;

        // Возрождение в случайной точке появления
        Random random = new Random();
        this.transform.setPosition(GameObjectCollection.spawnPoints.get(random.nextInt(GameObjectCollection.spawnPoints.size())).getTransform().getPosition());
    }

    // --- ДВИЖЕНИЕ ---
    private void rotateRight() {
        this.transform.rotate(this.ROTATION_SPEED); // Вращение по часовой стрелке
    }
    private void rotateLeft() {
        this.transform.rotate(-this.ROTATION_SPEED); // Вращение против часовой стрелки
    }
    private void moveForwards() {
        this.transform.move(this.moveSpeed); // Движение вперед
    }
    private void moveBackwards() {
        this.transform.move(-this.moveSpeed); // Движение назад
    }
    // --- ДВИЖЕНИЕ ---

    /**
     * Создает текущий снаряд и уменьшает количество боеприпасов.
     */
    private void fire() {
        if (this.fireCooldown >= this.fireDelay) {
            this.projectile = this.currentWeapon.createInstance(this.weaponSprite, this.damage, this);
            this.instantiate(this.projectile, this.transform.getPosition().add(this.originOffset), this.transform.getRotation());
            this.ammo--;
            this.fireCooldown = 0;
        }
    }

    /**
     * Получение урона от снарядов. Потеря жизни при 0 HP и поражение при 0 жизней.
     * @param damageDealt Урон от оружия
     */
    public void takeDamage(int damageDealt) {
        // Всегда наносить как минимум 1 единицу урона, независимо от брони
        this.currentHP -= Math.max(1, damageDealt - this.armor);
        if (this.currentHP <= 0) {
            this.currentLives--;
            if (this.currentLives <= 0) {
                this.loser = true;
                this.destroy(); // Уничтожение танка при поражении
            } else {
                this.respawn(); // Возрождение
            }
        }
    }

    // --- БОНУСЫ --- 
    public void addHealth(int value) {
    	if ((this.currentHP += value) >= this.MAX_HP) {
            this.currentHP = this.MAX_HP; /* Увеличение HP */
        }
    }
    public void addSpeed(int value) {
        if ((this.moveSpeed += value) >= 10) {
            this.moveSpeed = 10; /* Увеличение скорости */
        }
    }
    public void addFireRate(int value) {
        if ((this.fireRate += value) >= 10) {
            this.fireRate = 10; /* Увеличение скорострельности */
        }
    }
    public void addDamage(int value) {
        if ((this.damage += value) >= 10) {
            this.damage = 10; /* Увеличение урона */
        }
    }
    public void addArmor(int value) {
        if ((this.armor += value) >= 10) {
            this.armor = 10; /* Увеличение брони */
        }
    }
    public void addAmmo(int value) {
        if ((this.ammo += value) >= 999) {
            this.ammo = 999; /* Увеличение боеприпасов */
        }
    }
    public void setWeapon(Weapon.Type newWeapon, BufferedImage sprWeapon) {
        this.currentWeapon = newWeapon;
        this.weaponSprite = sprWeapon; /* Установка нового оружия */
    }
    public void setSprite(BufferedImage newSprite) {
        this.sprite = newSprite; /* Установка нового спрайта */
    }
    // --- БОНУСЫ ---

    /**
     * Передает текущее оружие танка в main.java.GameHUD для отрисовки на экране.
     */
    @Override
    public String getNameWeapon() {
    	switch(currentWeapon) {
    		case Bullet:
    			return "Пуля";
    		case Fireball:
    			return "Огненный шар";
    		case Boomerang:
    			return "Бумеранг";
    	}
		return null;
    }

    /**
     * Передает коэффициент перезарядки оружия в main.java.GameHUD для отрисовки на экране.
     * Используется в виде счетчика.
     */
    @Override
    public float getCooldownRatio() {
        return this.fireCooldown / this.fireDelay;
    }

    /**
     * Передает характеристики танка в main.java.GameHUD для отрисовки на экране.
     */
    @Override
    public LinkedHashMap<String, Integer> getStats() {
        this.statsCollection.put("Здоровье", this.currentHP);
        this.statsCollection.put("Жизни", this.currentLives);
        this.statsCollection.put("скорость", this.moveSpeed);
        this.statsCollection.put("Скорострельность", this.fireRate);
        this.statsCollection.put("Урон", this.damage);
        this.statsCollection.put("Броня", this.armor);
        this.statsCollection.put("Боеприпасы", this.ammo);

        return this.statsCollection;
    }

    /**
     * Управление движением танка и другими действиями, такими как выстрелы.
     */
    @Override
    public void update() {
        this.collider.setRect(this.transform.getPositionX(), this.transform.getPositionY(), this.width, this.height);

        // Перезарядка
        if (this.fireCooldown < this.fireDelay) {
            this.fireCooldown += this.fireRate;
        }

        // Движение
        if (this.UpPressed) {
            this.moveForwards();
        }
        if (this.DownPressed) {
            this.moveBackwards();
        }

        // Поворот
        if (this.LeftPressed) {
            this.rotateLeft();
        }
        if (this.RightPressed) {
            this.rotateRight();
        }

        // Выстрелы
        if (this.ActionPressed && this.ammo > 0) {
            this.fire();
        }
    }

    @Override
    public void collides(GameObject collidingObj) {
        collidingObj.handleCollision(this);
    }

    @Override
    public void handleCollision(Tank collidingTank) {
        collidingTank.solidCollision(this); // Сопротивление при столкновении, столкнувшийся танк медленно отталкивается назад
    }

    @Override
    public void handleCollision(Wall collidingWall) {
        this.solidCollision(collidingWall);
    }

    @Override
    public void handleCollision(Weapon collidingWeapon) {
        // Урон, обработанный в классе оружия
    }

    @Override
    public void handleCollision(Powerup collidingPowerup) {
        collidingPowerup.grantBonus(this);
        collidingPowerup.destroy();
    }

    /**
     * Отображает дополнительную информацию об объекте танка в игровом мире, например линию прицеливания.
     * @param g Графический объект, переданный для рисования игрового объекта
     */
    @Override
    public void drawGizmos(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor((this.getHPRatio() > 0.5) ? Color.GREEN : (this.getHPRatio() > 0.25) ? Color.YELLOW : Color.RED);

        // Отрисовка линии прицеливания
        float fromX = this.transform.getPositionX() + this.originOffset.getX();
        float fromY = this.transform.getPositionY() + this.originOffset.getY();
        float toX = (float) (this.getHPRatio() * 500 * Math.cos(Math.toRadians(this.transform.getRotation())));
        float toY = (float) (this.getHPRatio() * 500 * Math.sin(Math.toRadians(this.transform.getRotation())));
        g2d.drawLine((int) fromX, (int) fromY, (int) (fromX + toX), (int) (fromY + toY));
    }

    /**
     * Рисует переменные игрового объекта в игровом мире на графическом объекте g.
     * Этот метод вызывается, когда drawDebug включен в main.java.GamePanel.
     * @param g Графический объект, переданный для рисования игрового объекта
     */
    @Override
    public void drawVariables(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        g2d.drawString("здоровье: " + this.currentHP, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 60);
        g2d.drawString("скорость: " + this.moveSpeed, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 72);
        g2d.drawString("скорострельность: " + this.fireRate, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 84);
        g2d.drawString("урон: " + this.damage, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 96);
        g2d.drawString("броня: " + this.armor, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 108);
        g2d.drawString("боеприпасы: " + this.ammo, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 120);
    }

}
