package gameobjects;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Базовый класс для различных типов стен.
 */
public class Wall extends GameObject {

    /**
     * Определяет, может ли стена быть разрушена другими игровыми элементами.
     * @return true для разрушаемых стен, false для неразрушаемых
     */
    private boolean isBreakable;
    private int hitPoints;

    /**
     * Создает мягкую стену (разрушаемую) в указанной координате игрового мира с значением здоровья по умолчанию.
     * @param xPosition X-координата стены в игровом мире
     * @param yPosition Y-координата стены в игровом мире
     * @param sprite Изображение этой стены, отображаемое на экране
     */
    public Wall(float xPosition, float yPosition, float rotation, BufferedImage sprite, boolean isBreakable) {
        this.construct(xPosition, yPosition, rotation, sprite);
        this.isBreakable = isBreakable;

        this.init();
    }

    /**
     * Инициализирует стену со стандартными характеристиками.
     */
    private void init() {
        this.hitPoints = 1;
    }

    /**
     * Разрушаемые стены получают урон и имеют шанс случайно сбросить бонусы.
     * @param damageDealt Урон, нанесенный оружием
     */
    public void takeDamage(int damageDealt) {
        this.hitPoints -= damageDealt;

        // Шанс случайного появления бонусов при разрушении
        if (this.hitPoints <= 0) {
            double random = Math.random();
            if (random < 0.01) {
                // Низкий шанс появления бонуса "Максимальная сила"
                Powerup powerMax = new Powerup(Powerup.Type.Gold);
                this.instantiate(powerMax, this.transform.getPosition().add(this.originOffset), 0);
            } else if (random < 0.2) {
                // Случайный бонус с шансом 20%, исключая "Максимальная сила"
                Powerup powerup = new Powerup();
                this.instantiate(powerup, this.transform.getPosition().add(this.originOffset), 0);
            } else if (random < 0.25) {
                // Боеприпасы с шансом 25%, если случайный бонус не выпал
                Powerup powerAmmo = new Powerup(Powerup.Type.Ammo);
                this.instantiate(powerAmmo, this.transform.getPosition().add(this.originOffset), 0);
            }
            this.destroy();
        }
    }

    /**
     * Определяет, разрушаемая ли стена (мягкая стена) или неразрушаемая (жесткая стена).
     * @return Разрушаемая ли стена
     */
    public boolean isBreakable() {
        return this.isBreakable;
    }

    @Override
    public void update() {
        // Игнорируется, так как стены ничего не делают
    }

    @Override
    public void collides(GameObject collidingObj) {
        collidingObj.handleCollision(this);
    }

    @Override
    public void handleCollision(Tank collidingTank) {

    }

    @Override
    public void handleCollision(Wall collidingWall) {

    }

    @Override
    public void handleCollision(Weapon collidingWeapon) {

    }

    @Override
    public void handleCollision(Powerup collidingPowerup) {

    }

    @Override
    public void drawGizmos(Graphics g) {

    }

    /**
     * Рисует переменные игрового объекта в игровом мире на графическом объекте g.
     * Этот метод вызывается, когда drawDebug включен в main.java.GamePanel.
     * @param g Графический объект, переданный для рисования игрового объекта
     */
    @Override
    public void drawVariables(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawString("hitPoints: " + this.hitPoints, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 60);
        g2d.drawString("isBreakable: " + this.isBreakable, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 72);
    }

}