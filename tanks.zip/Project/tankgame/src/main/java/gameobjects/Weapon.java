package gameobjects;

import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Абстрактный класс для оружия с заранее определенными типами оружия.
 */
public abstract class Weapon extends GameObject {
    // Возможные типы оружия, определенные заранее
    enum Type {
        // Обычная пуля
        Bullet {
            @Override
            public Weapon createInstance(BufferedImage sprite, int damage, Tank shooter) {
                return new Bullet(sprite, damage, shooter);
            }
        },

        // Быстрый снаряд, разрушающий несколько разрушаемых стен
        Fireball {
            @Override
            public Weapon createInstance(BufferedImage sprite, int damage, Tank shooter) {
                return new Fireball(sprite, damage, shooter);
            }
        },

        // Снаряд с медленной начальной скоростью, который меняет направление и ускоряется
        Boomerang {
            @Override
            public Weapon createInstance(BufferedImage sprite, int damage, Tank shooter) {
                return new Boomerang(sprite, damage, shooter);
            }
        };
    	
        public abstract Weapon createInstance(BufferedImage sprite, int damage, Tank shooter);

    }

    protected Tank shooter; // Танк, изначально выпустивший оружие. Это предотвращает повреждение себя.

    protected int damage;
    protected float velocity;
    protected int hitPoints;

    /**
     * Инициализация оружия со стандартными характеристиками.
     */
    protected abstract void init();

    /**
     * Когда оружие получает урон при столкновении, оно в конечном итоге уничтожается.
     * Оружие может быть уничтожено сразу или после нескольких столкновений (например, fireball).
     */
    public void takeDamage() {
        this.hitPoints--;
        if (this.hitPoints <= 0) {
            this.destroy();
        }
    }

    /**
     * Постоянное движение в направлении вращения объекта оружия с заданной скоростью.
     */
    @Override
    public void update() {
        this.collider.setRect(this.transform.getPositionX(), this.transform.getPositionY(), this.width, this.height);
        this.transform.move(this.velocity);
    }

    @Override
    public void collides(GameObject collidingObj) {
        collidingObj.handleCollision(this);
    }

    @Override
    public void handleCollision(Tank collidingTank) {
        // Предотвращает попадание оружия в собственный танк, который его выпустил
        if (collidingTank != this.shooter) {
            collidingTank.takeDamage(this.damage);
            this.takeDamage();
        }
    }

    @Override
    public void handleCollision(Wall collidingWall) {
        if (collidingWall.isBreakable()) {
            collidingWall.takeDamage(this.damage);
        }
        this.takeDamage();
    }

    @Override
    public void handleCollision(Weapon collidingWeapon) {
        // Пули проходят друг через друга, если они не выпущены другим игроком
        if (collidingWeapon.shooter != this.shooter) {
            collidingWeapon.takeDamage();
        }
    }

    @Override
    public void handleCollision(Powerup collidingPowerup) {

    }

    /**
     * Отображает дополнительную информацию об объекте оружия в игровом мире.
     * @param g Графический объект, переданный для рисования игрового объекта
     */
    @Override
    public void drawGizmos(Graphics g) {

    }

    /**
     * Рисует переменные игрового объекта в игровом мире на графическом объекте g.
     * Этот метод вызывается, когда drawDebug включен в main.java.GamePanel.
     * @param g Графический объект, переданный для рисования игрового объекта
     */
    @Override
    public void drawVariables(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        g2d.drawString("damage: " + this.damage, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 60);
        g2d.drawString("velocity: " + this.velocity, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 72);
        g2d.drawString("hitPoints: " + this.hitPoints, this.transform.getPositionX(), this.transform.getPositionY() + this.height + 84);
    }

}