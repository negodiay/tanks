package gameobjects;

import java.util.ArrayList;

/**
 * Хранит статический список игровых объектов, присутствующих в игровом мире.
 */
public class GameObjectCollection {

    private static ArrayList<GameObject> gameObjects; // Список всех игровых объектов
    public static ArrayList<Spawn> spawnPoints; // Точки появления для возрождения танков

    /**
     * Вызывается при инициализации игры с картой и запуске игрового процесса.
     */
    public static void init() {
        gameObjects = new ArrayList<>(); // Создание списка игровых объектов
        spawnPoints = new ArrayList<>(); // Создание списка точек появления
    }

    /**
     * Создает игровой объект в игровом мире.
     * @param obj Игровой объект, который будет создан
     */
    public static void spawn(GameObject obj) {
        gameObjects.add(obj); // Добавление объекта в список
    }

    /**
     * Удаляет игровой объект из игрового мира.
     * @param obj Игровой объект, который будет удален
     */
    public static void destroy(GameObject obj) {
        gameObjects.remove(obj); // Удаление объекта из списка
    }

    /**
     * Подсчитывает количество игровых объектов, присутствующих в игровом мире.
     * @return Количество игровых объектов в списке
     */
    public static int numGameObjects() {
        return gameObjects.size(); // Возвращает размер списка
    }

    /**
     * Получает определённый игровой объект из списка по указанному индексу.
     * @param index Индекс в списке
     * @return Игровой объект из списка по указанному индексу
     */
    public static GameObject getGameObject(int index) {
        return gameObjects.get(index); // Возвращает объект по индексу
    }
}