package gameobjects;

import util.Transform;

/**
 * Точка появления (Spawn point) для возрождения танков.
 */
public class Spawn {

    private Transform transform; // Трансформация (позиция, вращение) точки появления

    // Конструктор по умолчанию
    public Spawn() {
        this.transform = new Transform();
    }

    // Конструктор с указанием позиции и угла вращения
    public Spawn(float xPosition, float yPosition, float rotation) {
        this.transform = new Transform(xPosition, yPosition, rotation);
    }

    // Получить трансформацию точки появления
    public Transform getTransform() {
        return this.transform;
    }

}
