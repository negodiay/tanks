package gameobjects;

import util.Transform;

import java.awt.image.BufferedImage;

/**
 * Объекты пули, которые выпускаются объектами танков.
 */
public class Bullet extends Weapon {

    /**
     * Создает новый объект пули с базовыми данными.
     * @param sprite Изображение этой пули, передаваемое объектом танка для отрисовки на экране
     * @param damage Дополнительный урон, передаваемый объектом танка, добавляется к базовому урону
     * @param shooter Танк, который выпустил эту пулю, предотвращает попадание в самого себя
     */
    public Bullet(BufferedImage sprite, int damage, Tank shooter) {
        this.transform = new Transform(); // Инициализация объекта Transform для управления положением
        this.construct(sprite); // Установка изображения пули
        this.shooter = shooter; // Указание танка, выпустившего пулю

        this.damage += damage; // Добавление дополнительного урона к базовому
        this.init(); // Инициализация стандартных параметров
    }

    /**
     * Инициализирует оружие с параметрами по умолчанию.
     */
    @Override
    protected void init() {
        this.velocity = 12.0f; // Устанавливается скорость пули
        this.hitPoints = 1;   // Количество здоровья пули (например, пуля исчезает после столкновения)
    }

}
